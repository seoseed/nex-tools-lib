# nex-tools-lib

Wiederverwendbare Python-Bibliothek für KI-gestützte Automatisierung, Parsing und Analyseprozesse.