from openai import OpenAI
import os

def generate_summary(text: str) -> str:
    prompt = f"Fasse den folgenden Text in 3 Sätzen zusammen:\n\n{text}"
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content.strip()
